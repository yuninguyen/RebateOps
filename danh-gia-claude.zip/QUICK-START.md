# 🚀 QUICK START GUIDE

> Hướng dẫn setup nhanh cho người mới bắt đầu

---

## 📦 BẠN CẦN CÀI ĐẶT GÌ?

### 1. **PHP 8.2+**
```bash
# Kiểm tra version PHP
php -v

# Nếu chưa có, download tại:
# Windows: https://windows.php.net/download/
# Mac: brew install php@8.2
# Linux: sudo apt install php8.2
```

### 2. **Composer**
```bash
# Kiểm tra
composer -v

# Nếu chưa có:
# https://getcomposer.org/download/
```

### 3. **Node.js & NPM**
```bash
# Kiểm tra
node -v
npm -v

# Nếu chưa có:
# https://nodejs.org/
```

### 4. **Git**
```bash
# Kiểm tra
git --version

# Nếu chưa có:
# https://git-scm.com/downloads
```

---

## 🎬 5 BƯỚC SETUP DỰ ÁN

### **Bước 1: Clone dự án**
```bash
# Mở Terminal/Command Prompt
cd Desktop  # hoặc thư mục bạn muốn
git clone https://github.com/yuninguyen/yuni-legend.git
cd yuni-legend
```

### **Bước 2: Cài đặt dependencies**
```bash
# Cài PHP packages
composer install

# Cài JavaScript packages
npm install
```
⏱️ **Thời gian:** ~3-5 phút

### **Bước 3: Tạo môi trường**
```bash
# Copy file environment
cp .env.example .env

# Generate app key (QUAN TRỌNG!)
php artisan key:generate

# Tạo database file (SQLite)
touch database/database.sqlite

# Chạy migrations (Tạo tables)
php artisan migrate
```

### **Bước 4: Setup Google Sheets**

#### 4.1. Tạo Google Cloud Project
1. Vào https://console.cloud.google.com/
2. Tạo project mới (ví dụ: "Yuni-Legend")
3. Enable "Google Sheets API"

#### 4.2. Tạo Service Account
1. Vào "IAM & Admin" → "Service Accounts"
2. Create Service Account
3. Tên: `yuni-sheets-service`
4. Download JSON credentials
5. Đổi tên thành `google-auth.json`
6. Copy vào `storage/app/google-auth.json`

#### 4.3. Share Google Sheet
1. Mở file Google-auth.json
2. Copy email (dạng: xxx@xxx.iam.gserviceaccount.com)
3. Mở Google Sheet của bạn
4. Click "Share"
5. Paste email và cho quyền "Editor"
6. Copy Spreadsheet ID từ URL:
   ```
   https://docs.google.com/spreadsheets/d/[SPREADSHEET_ID]/edit
   ```

#### 4.4. Update .env
```bash
# Mở file .env và thêm:
GOOGLE_SPREADSHEET_ID=paste_id_here
```

### **Bước 5: Tạo Admin User & Chạy**
```bash
# Tạo admin user
php artisan make:filament-user

# Nhập thông tin:
# Name: Admin
# Email: admin@example.com
# Password: password (hoặc gì bạn muốn)

# Chạy ứng dụng
composer run dev
```

---

## 🌐 TRUY CẬP ỨNG DỤNG

### Sau khi chạy `composer run dev`, bạn sẽ thấy:

```bash
✅ Server started: http://localhost:8000
✅ Queue worker started
✅ Vite dev server: http://localhost:5173
```

### Truy cập:
- **Trang chính:** http://localhost:8000
- **Admin Panel:** http://localhost:8000/admin
  - Email: admin@example.com
  - Password: (password bạn đã tạo)

---

## ❓ TROUBLESHOOTING - Gặp lỗi?

### **Lỗi 1: "composer: command not found"**
```bash
# Cài đặt Composer:
# https://getcomposer.org/download/

# Verify:
composer -v
```

### **Lỗi 2: "npm: command not found"**
```bash
# Cài đặt Node.js:
# https://nodejs.org/

# Verify:
node -v
npm -v
```

### **Lỗi 3: "could not find driver" (SQLite)**
```bash
# Cài SQLite extension cho PHP

# Windows: Uncomment trong php.ini
extension=pdo_sqlite
extension=sqlite3

# Linux:
sudo apt install php-sqlite3

# Mac:
# Thường đã có sẵn
```

### **Lỗi 4: "SQLSTATE[HY000] [2002] Connection refused" (MySQL)**
```bash
# Nếu bạn đổi sang MySQL:
# 1. Kiểm tra MySQL đang chạy
# 2. Verify thông tin trong .env:
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=yuni_legend
DB_USERNAME=root
DB_PASSWORD=your_password
```

### **Lỗi 5: Google Sheets API Error**
```bash
# Kiểm tra:
# ✅ File google-auth.json có đúng path không?
# ✅ Sheet đã được share với service account chưa?
# ✅ GOOGLE_SPREADSHEET_ID trong .env đúng chưa?
# ✅ Google Sheets API đã enable chưa?
```

### **Lỗi 6: "Port 8000 already in use"**
```bash
# Đổi port khác:
php artisan serve --port=8080

# Hoặc kill process đang dùng port 8000
# Windows: netstat -ano | findstr :8000
# Mac/Linux: lsof -ti:8000 | xargs kill
```

---

## 📱 CÁC LỆNH THƯỜNG DÙNG

```bash
# Chạy ứng dụng (Development mode)
composer run dev

# Chạy migration (Tạo tables)
php artisan migrate

# Xóa DB và chạy lại migrations
php artisan migrate:fresh

# Chạy migrations + seed data
php artisan migrate --seed

# Tạo admin user mới
php artisan make:filament-user

# Xóa cache
php artisan cache:clear
php artisan config:clear
php artisan view:clear

# Xem routes
php artisan route:list

# Chạy queue worker (Xử lý background jobs)
php artisan queue:work

# Chạy tests
php artisan test

# Check code style
./vendor/bin/pint
```

---

## 📂 CẤU TRÚC DỰ ÁN QUAN TRỌNG

```
yuni-legend/
├── app/
│   ├── Models/              # Database models
│   ├── Filament/            # Admin panel UI
│   ├── Services/            # Business logic
│   ├── Jobs/                # Background jobs
│   └── Observers/           # Event observers
├── database/
│   ├── migrations/          # Database schema
│   └── database.sqlite      # SQLite database file
├── storage/
│   └── app/
│       └── google-auth.json # Google credentials
├── .env                     # Environment config
└── composer.json            # PHP dependencies
```

---

## 🎓 HỌC THÊM

### Laravel
- [Laravel Documentation](https://laravel.com/docs/12.x)
- [Laracasts Video Tutorials](https://laracasts.com)
- [Laravel Daily YouTube](https://www.youtube.com/@LaravelDaily)

### Filament
- [Filament Documentation](https://filamentphp.com/docs)
- [Filament Examples](https://demo.filamentphp.com)

### Google Sheets API
- [Google Sheets API Guide](https://developers.google.com/sheets/api/guides/concepts)
- [PHP Client Library](https://github.com/googleapis/google-api-php-client)

---

## 💬 CẦN GIÚP ĐỠ?

### Communities:
- **Laravel Vietnam:** https://www.facebook.com/groups/vietnam.laravel/
- **Laravel Discord:** https://discord.gg/laravel
- **Filament Discord:** https://discord.gg/filamentphp

### Stack Overflow:
- Tag: `laravel`, `filament`, `google-sheets-api`

---

## ✅ CHECKLIST HOÀN THÀNH

Đánh dấu khi bạn hoàn thành từng bước:

- [ ] Cài đặt PHP 8.2+
- [ ] Cài đặt Composer
- [ ] Cài đặt Node.js & NPM
- [ ] Clone dự án
- [ ] Chạy `composer install`
- [ ] Chạy `npm install`
- [ ] Copy .env.example → .env
- [ ] Generate app key
- [ ] Tạo database.sqlite
- [ ] Chạy migrations
- [ ] Setup Google Sheets credentials
- [ ] Tạo admin user
- [ ] Chạy ứng dụng thành công
- [ ] Truy cập được admin panel
- [ ] Test Google Sheets sync

---

## 🎉 CHÚC MỪNG!

Nếu bạn đã hoàn thành tất cả các bước trên, dự án của bạn đã sẵn sàng!

**Next Steps:**
1. Đọc file `project-review.md` để hiểu toàn bộ dự án
2. Xem `TODO-CHECKLIST.md` để biết cần làm gì tiếp theo
3. Bắt đầu code! 💻

---

**Happy Coding!** 🚀
